
const form = document.getElementById("formInscription");

form.addEventListener("submit", function(e) {

    e.preventDefault();

    let nom = document.getElementById("nom").value.trim();
    let prenom = document.getElementById("prenom").value.trim();
    let email = document.getElementById("email").value.trim();
    let password = document.getElementById("password").value;
    let confirmPassword = document.getElementById("confirmPassword").value;
    let telephone = document.getElementById("telephone").value.trim();
    let langue = document.getElementById("langue").value;
    let commentaire = document.getElementById("commentaire").value.trim();


    if(password !== confirmPassword) {
        alert("Les mots de passe ne correspondent pas !");
        return;
    }

    if(isNaN(telephone)) {
        alert("Le téléphone doit contenir uniquement des chiffres !");
        return;
    }

    document.getElementById("recap").innerHTML = `
        <h3>Récapitulatif :</h3>
        <p><strong>Nom :</strong> ${nom}</p>
        <p><strong>Prénom :</strong> ${prenom}</p>
        <p><strong>Email :</strong> ${email}</p>
        <p><strong>Téléphone :</strong> ${telephone}</p>
        <p><strong>Langue :</strong> ${langue}</p>
        <p><strong>Commentaire :</strong> ${commentaire}</p>
    `;
});
