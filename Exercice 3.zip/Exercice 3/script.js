const form = document.getElementById("studentForm");

form.addEventListener("submit", function(e) {
  e.preventDefault();

  // Reset errors
  document.querySelectorAll(".error").forEach(el => el.textContent = "");

  let code = document.getElementById("code").value.trim();
  let nom = document.getElementById("nom").value.trim();
  let prenom = document.getElementById("prenom").value.trim();
  let semestre = document.getElementById("semestre").value;

  let m1 = parseFloat(document.getElementById("m1").value);
  let m2 = parseFloat(document.getElementById("m2").value);
  let m3 = parseFloat(document.getElementById("m3").value);
  let m4 = parseFloat(document.getElementById("m4").value);
  let m5 = parseFloat(document.getElementById("m5").value);
  let m6 = parseFloat(document.getElementById("m6").value);

  let valid = true;

  if (code === "") {
    document.getElementById("error-code").textContent = "Code obligatoire";
    valid = false;
  }

  if (nom === "") {
    document.getElementById("error-nom").textContent = "Nom obligatoire";
    valid = false;
  }

  if (prenom === "") {
    document.getElementById("error-prenom").textContent = "Prénom obligatoire";
    valid = false;
  }

  if (semestre === "") {
    document.getElementById("error-semestre").textContent = "Choisir un semestre";
    valid = false;
  }

  const notes = [m1, m2, m3, m4, m5, m6];
  if (notes.some(n => isNaN(n))) {
    document.getElementById("error-notes").textContent = "Toutes les notes doivent être saisies (nombre)";
    valid = false;
  }

  if (!valid) return;

  // Calcul moyenne
  let moyenne = notes.reduce((a, b) => a + b, 0) / 6;

  let nonValides = 0;
  let eliminatoire = false;

  notes.forEach(note => {
    if (note < 12) nonValides++;
    if (note < 8) eliminatoire = true;
  });

  let decision = (eliminatoire || nonValides >= 3)
    ? "Semestre Échoué"
    : "Semestre Validé";

  // Ajouter au tableau
  const tbody = document.querySelector("#table tbody");
  const row = document.createElement("tr");

  const data = [code, nom, prenom, semestre, ...notes, moyenne.toFixed(2), decision];

  data.forEach(val => {
    let td = document.createElement("td");
    td.textContent = val;
    row.appendChild(td);
  });

  tbody.appendChild(row);

  form.reset();
});
