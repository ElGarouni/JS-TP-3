const form = document.getElementById("form");
const dimInput = document.getElementById("dim");
const minInput = document.getElementById("min");
const maxInput = document.getElementById("max");
const errorEl = document.getElementById("error");
const resultEl = document.getElementById("result");

function isIntegerString(s) {
  // تقبل غير أرقام صحيحة (حتى - إذا بغيتي، حيدو إذا ما بغيتيش سالب)
  return /^-?\d+$/.test(s.trim());
}

function randInt(min, max) {
  // inclusive
  return Math.floor(Math.random() * (max - min + 1)) + min;
}

form.addEventListener("submit", (e) => {
  e.preventDefault();
  errorEl.textContent = "";
  resultEl.innerHTML = "";

  const dimStr = dimInput.value.trim();
  const minStr = minInput.value.trim();
  const maxStr = maxInput.value.trim();

  // 1) Check empty
  if (!dimStr || !minStr || !maxStr) {
    errorEl.textContent = "Erreur: Tous les champs sont obligatoires.";
    return;
  }

  // 2) Check integers
  if (!isIntegerString(dimStr) || !isIntegerString(minStr) || !isIntegerString(maxStr)) {
    errorEl.textContent = "Erreur: Veuillez saisir des entiers valides.";
    return;
  }

  const dim = parseInt(dimStr, 10);
  const min = parseInt(minStr, 10);
  const max = parseInt(maxStr, 10);

  // 3) Check dimension positive
  if (dim <= 0) {
    errorEl.textContent = "Erreur: La dimension doit être un entier > 0.";
    return;
  }

  // 4) Check min < max
  if (min >= max) {
    errorEl.textContent = "Erreur: La valeur minimale doit être inférieure à la valeur maximale.";
    return;
  }

  // Generate table
  const table = document.createElement("table");

  let tr = document.createElement("tr");

  for (let i = 1; i <= dim; i++) {
    const td = document.createElement("td");
    td.textContent = randInt(min, max);
    tr.appendChild(td);

    // كلما وصلنا 10 خلايا، نسدو السطر ونفتحو واحد جديد
    if (i % 10 === 0) {
      table.appendChild(tr);
      tr = document.createElement("tr");
    }
  }

  // إذا بقا شي خلايا أقل من 10 ف الأخير، نزيدو داك السطر
  if (tr.children.length > 0) {
    table.appendChild(tr);
  }

  resultEl.appendChild(table);
});
